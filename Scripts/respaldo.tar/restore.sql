--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.sg_tb_user_rol DROP CONSTRAINT usuario_usuario_rol_fk;
ALTER TABLE ONLY public.sg_tb_usuario DROP CONSTRAINT sg_tb_usuario_persona_asociada_id_fkey;
ALTER TABLE ONLY public.sg_tb_user_rol DROP CONSTRAINT rol_usuario_rol_fk;
ALTER TABLE ONLY public.cs_tb_prestador_medico DROP CONSTRAINT prestador_usuario_fk;
ALTER TABLE ONLY public.cs_tb_prestador_medico DROP CONSTRAINT prestador_persona_fk;
ALTER TABLE ONLY public.cs_tb_consulta DROP CONSTRAINT persona_id_fk;
DROP INDEX public.indx_fechas_continuas;
ALTER TABLE ONLY public.tb_ps_parametros_sistema DROP CONSTRAINT tb_ps_parametros_sistema_pkey;
ALTER TABLE ONLY public.tb_ps_parametros_sistema DROP CONSTRAINT tb_ps_parametros_sistema_nombre_key;
ALTER TABLE ONLY public.tb_fc_fechas_continuas DROP CONSTRAINT tb_fc_fechas_continuas_pkey;
ALTER TABLE ONLY public.sg_tb_usuario DROP CONSTRAINT sg_tb_usuario_persona_asociada_id_key;
ALTER TABLE ONLY public.sg_tb_usuario DROP CONSTRAINT sg_tb_usuario_identificador_key;
ALTER TABLE ONLY public.sg_tb_user_rol DROP CONSTRAINT sg_tb_user_rol_pk;
ALTER TABLE ONLY public.sg_tb_usuario DROP CONSTRAINT sg_tb_user_pk;
ALTER TABLE ONLY public.sg_tb_rol DROP CONSTRAINT sg_tb_rol_pk;
ALTER TABLE ONLY public.cs_tb_prestador_medico DROP CONSTRAINT prestador_medico_id_pk;
ALTER TABLE ONLY public.bs_tb_persona DROP CONSTRAINT persona_unique_identificador;
ALTER TABLE ONLY public.bs_tb_persona DROP CONSTRAINT persona_id_pk;
ALTER TABLE ONLY public.cs_tb_consulta DROP CONSTRAINT consulta_id_pk;
ALTER TABLE ONLY public.bs_tb_sexo DROP CONSTRAINT bs_tb_sexo_pkey;
DROP VIEW public.vw_cd_consultas_diarias;
DROP VIEW public.vw_rc_resumen_consultas;
DROP TABLE public.tb_ps_parametros_sistema;
DROP TABLE public.tb_fc_fechas_continuas;
DROP VIEW public.segu_vta_jaas;
DROP TABLE public.sg_tb_usuario;
DROP TABLE public.sg_tb_user_rol;
DROP TABLE public.sg_tb_rol;
DROP SEQUENCE public.sg_sq_user_rol;
DROP SEQUENCE public.sg_sq_user;
DROP SEQUENCE public.sg_sq_rol;
DROP TABLE public.cs_tb_prestador_medico;
DROP TABLE public.cs_tb_consulta;
DROP SEQUENCE public.cs_sq_prestador_medico;
DROP SEQUENCE public.cs_sq_consulta;
DROP TABLE public.bs_tb_sexo;
DROP TABLE public.bs_tb_persona;
DROP SEQUENCE public.bs_sq_persona;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: bs_sq_persona; Type: SEQUENCE; Schema: public; Owner: modulo_base
--

CREATE SEQUENCE bs_sq_persona
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bs_sq_persona OWNER TO modulo_base;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: bs_tb_persona; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE bs_tb_persona (
    persona_id numeric(9,0) DEFAULT nextval('bs_sq_persona'::regclass) NOT NULL,
    identificador character varying(15) NOT NULL,
    nombres character varying(100) NOT NULL,
    apellidos character varying(100) NOT NULL,
    sexo numeric(1,0) NOT NULL,
    fecha_nacimiento date NOT NULL,
    reg_fec_insert timestamp without time zone NOT NULL,
    reg_fec_update timestamp without time zone
);


ALTER TABLE public.bs_tb_persona OWNER TO modulo_base;

--
-- Name: bs_tb_sexo; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE bs_tb_sexo (
    sexo_id numeric(1,0) NOT NULL,
    descripcion character varying(50)
);


ALTER TABLE public.bs_tb_sexo OWNER TO modulo_base;

--
-- Name: cs_sq_consulta; Type: SEQUENCE; Schema: public; Owner: modulo_base
--

CREATE SEQUENCE cs_sq_consulta
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cs_sq_consulta OWNER TO modulo_base;

--
-- Name: cs_sq_prestador_medico; Type: SEQUENCE; Schema: public; Owner: modulo_base
--

CREATE SEQUENCE cs_sq_prestador_medico
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cs_sq_prestador_medico OWNER TO modulo_base;

--
-- Name: cs_tb_consulta; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE cs_tb_consulta (
    consulta_id numeric(9,0) DEFAULT nextval('cs_sq_consulta'::regclass) NOT NULL,
    txt_desarrollo text NOT NULL,
    fecha_inicio_consulta timestamp without time zone NOT NULL,
    persona_paciente_id numeric(9,0) NOT NULL,
    reg_fec_insert timestamp without time zone NOT NULL,
    reg_fec_update timestamp without time zone,
    fecha_fin_consulta timestamp without time zone NOT NULL
);


ALTER TABLE public.cs_tb_consulta OWNER TO modulo_base;

--
-- Name: cs_tb_prestador_medico; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE cs_tb_prestador_medico (
    prestador_medico_id numeric(9,0) DEFAULT nextval('cs_sq_prestador_medico'::regclass) NOT NULL,
    usuario_id numeric(9,0) NOT NULL,
    persona_id numeric(9,0) NOT NULL,
    reg_fec_insert timestamp without time zone NOT NULL,
    reg_fec_update timestamp without time zone,
    profesion character varying(500) NOT NULL,
    especialidad character varying(500) NOT NULL
);


ALTER TABLE public.cs_tb_prestador_medico OWNER TO modulo_base;

--
-- Name: sg_sq_rol; Type: SEQUENCE; Schema: public; Owner: modulo_base
--

CREATE SEQUENCE sg_sq_rol
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sg_sq_rol OWNER TO modulo_base;

--
-- Name: sg_sq_user; Type: SEQUENCE; Schema: public; Owner: modulo_base
--

CREATE SEQUENCE sg_sq_user
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sg_sq_user OWNER TO modulo_base;

--
-- Name: sg_sq_user_rol; Type: SEQUENCE; Schema: public; Owner: modulo_base
--

CREATE SEQUENCE sg_sq_user_rol
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sg_sq_user_rol OWNER TO modulo_base;

--
-- Name: sg_tb_rol; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE sg_tb_rol (
    rol_id numeric(9,0) DEFAULT nextval('sg_sq_rol'::regclass) NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion character varying(140) NOT NULL,
    identificador character varying(50) NOT NULL,
    reg_fec_update timestamp without time zone,
    reg_fec_insert timestamp without time zone NOT NULL
);


ALTER TABLE public.sg_tb_rol OWNER TO modulo_base;

--
-- Name: sg_tb_user_rol; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE sg_tb_user_rol (
    usuario_rol_id numeric(9,0) DEFAULT nextval('sg_sq_user_rol'::regclass) NOT NULL,
    usuario_id numeric(9,0) NOT NULL,
    rol_id numeric(9,0) NOT NULL,
    valido_desde timestamp without time zone NOT NULL,
    valido_hasta timestamp without time zone,
    reg_fec_insert timestamp without time zone NOT NULL,
    reg_fec_update timestamp without time zone
);


ALTER TABLE public.sg_tb_user_rol OWNER TO modulo_base;

--
-- Name: sg_tb_usuario; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE sg_tb_usuario (
    usuario_id numeric(9,0) DEFAULT nextval('sg_sq_user'::regclass) NOT NULL,
    identificador character varying(50) NOT NULL,
    clave character varying(64) NOT NULL,
    reg_fec_insert timestamp without time zone NOT NULL,
    reg_fec_update timestamp without time zone,
    email character varying(140),
    flag_cambiar_clave numeric(1,0) DEFAULT 0,
    persona_asociada_id numeric(9,0)
);


ALTER TABLE public.sg_tb_usuario OWNER TO modulo_base;

--
-- Name: TABLE sg_tb_usuario; Type: COMMENT; Schema: public; Owner: modulo_base
--

COMMENT ON TABLE sg_tb_usuario IS 'registro de los usuarios del sistema.';


--
-- Name: COLUMN sg_tb_usuario.email; Type: COMMENT; Schema: public; Owner: modulo_base
--

COMMENT ON COLUMN sg_tb_usuario.email IS 'correo electronico del usuario.';


--
-- Name: COLUMN sg_tb_usuario.flag_cambiar_clave; Type: COMMENT; Schema: public; Owner: modulo_base
--

COMMENT ON COLUMN sg_tb_usuario.flag_cambiar_clave IS '0 es no hacer nada, 1 cambiar clave en proximo login';


--
-- Name: segu_vta_jaas; Type: VIEW; Schema: public; Owner: modulo_base
--

CREATE VIEW segu_vta_jaas AS
 SELECT u.identificador AS jaas_user,
    u.clave AS jaas_password,
    r.identificador AS jaas_rol
   FROM ((sg_tb_user_rol ur
   JOIN sg_tb_usuario u ON ((ur.usuario_id = u.usuario_id)))
   JOIN sg_tb_rol r ON ((ur.rol_id = r.rol_id)))
  WHERE ((now() >= ur.valido_desde) AND (now() <= ur.valido_hasta));


ALTER TABLE public.segu_vta_jaas OWNER TO modulo_base;

--
-- Name: tb_fc_fechas_continuas; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE tb_fc_fechas_continuas (
    fecha date NOT NULL
);


ALTER TABLE public.tb_fc_fechas_continuas OWNER TO modulo_base;

--
-- Name: tb_ps_parametros_sistema; Type: TABLE; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE TABLE tb_ps_parametros_sistema (
    nombre character varying(50) NOT NULL,
    valor character varying(200),
    ps_id numeric(6,0) NOT NULL
);


ALTER TABLE public.tb_ps_parametros_sistema OWNER TO modulo_base;

--
-- Name: vw_rc_resumen_consultas; Type: VIEW; Schema: public; Owner: modulo_base
--

CREATE VIEW vw_rc_resumen_consultas AS
 SELECT cs.consulta_id AS vista_id,
    fc.fecha AS fecha_consulta,
    cs.fecha_inicio_consulta AS fecha_hora,
    (date_part('minute'::text, (cs.reg_fec_insert - cs.fecha_inicio_consulta)))::numeric AS duracion,
    (((date_part('minute'::text, (cs.reg_fec_insert - cs.fecha_inicio_consulta)) || ' minutos, '::text) || date_part('second'::text, (cs.reg_fec_insert - cs.fecha_inicio_consulta))) || ' segundos'::text) AS duracion_exacta,
    per.identificador AS paciente,
    sx.descripcion AS sexo
   FROM (((cs_tb_consulta cs
   JOIN bs_tb_persona per ON ((cs.persona_paciente_id = per.persona_id)))
   JOIN bs_tb_sexo sx ON ((sx.sexo_id = per.sexo)))
   RIGHT JOIN tb_fc_fechas_continuas fc ON (((cs.fecha_inicio_consulta)::date = fc.fecha)))
  WHERE ((fc.fecha >= '2014-09-01'::date) AND (fc.fecha <= '2015-12-31'::date))
  ORDER BY fc.fecha;


ALTER TABLE public.vw_rc_resumen_consultas OWNER TO modulo_base;

--
-- Name: vw_cd_consultas_diarias; Type: VIEW; Schema: public; Owner: modulo_base
--

CREATE VIEW vw_cd_consultas_diarias AS
 WITH por_dia AS (
         SELECT rc.fecha_consulta,
            count(rc.vista_id) AS cantidad
           FROM vw_rc_resumen_consultas rc
          WHERE (1 = 1)
          GROUP BY rc.fecha_consulta
          ORDER BY rc.fecha_consulta
        )
 SELECT fc.fecha AS dia,
    pd.cantidad
   FROM (por_dia pd
   RIGHT JOIN tb_fc_fechas_continuas fc ON ((pd.fecha_consulta = fc.fecha)))
  WHERE ((fc.fecha >= '2014-10-01'::date) AND (fc.fecha <= '2015-12-31'::date));


ALTER TABLE public.vw_cd_consultas_diarias OWNER TO modulo_base;

--
-- Name: bs_sq_persona; Type: SEQUENCE SET; Schema: public; Owner: modulo_base
--

SELECT pg_catalog.setval('bs_sq_persona', 40, true);


--
-- Data for Name: bs_tb_persona; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY bs_tb_persona (persona_id, identificador, nombres, apellidos, sexo, fecha_nacimiento, reg_fec_insert, reg_fec_update) FROM stdin;
\.
COPY bs_tb_persona (persona_id, identificador, nombres, apellidos, sexo, fecha_nacimiento, reg_fec_insert, reg_fec_update) FROM '$$PATH$$/2030.dat';

--
-- Data for Name: bs_tb_sexo; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY bs_tb_sexo (sexo_id, descripcion) FROM stdin;
\.
COPY bs_tb_sexo (sexo_id, descripcion) FROM '$$PATH$$/2031.dat';

--
-- Name: cs_sq_consulta; Type: SEQUENCE SET; Schema: public; Owner: modulo_base
--

SELECT pg_catalog.setval('cs_sq_consulta', 91, true);


--
-- Name: cs_sq_prestador_medico; Type: SEQUENCE SET; Schema: public; Owner: modulo_base
--

SELECT pg_catalog.setval('cs_sq_prestador_medico', 5, true);


--
-- Data for Name: cs_tb_consulta; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY cs_tb_consulta (consulta_id, txt_desarrollo, fecha_inicio_consulta, persona_paciente_id, reg_fec_insert, reg_fec_update, fecha_fin_consulta) FROM stdin;
\.
COPY cs_tb_consulta (consulta_id, txt_desarrollo, fecha_inicio_consulta, persona_paciente_id, reg_fec_insert, reg_fec_update, fecha_fin_consulta) FROM '$$PATH$$/2034.dat';

--
-- Data for Name: cs_tb_prestador_medico; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY cs_tb_prestador_medico (prestador_medico_id, usuario_id, persona_id, reg_fec_insert, reg_fec_update, profesion, especialidad) FROM stdin;
\.
COPY cs_tb_prestador_medico (prestador_medico_id, usuario_id, persona_id, reg_fec_insert, reg_fec_update, profesion, especialidad) FROM '$$PATH$$/2035.dat';

--
-- Name: sg_sq_rol; Type: SEQUENCE SET; Schema: public; Owner: modulo_base
--

SELECT pg_catalog.setval('sg_sq_rol', 6, true);


--
-- Name: sg_sq_user; Type: SEQUENCE SET; Schema: public; Owner: modulo_base
--

SELECT pg_catalog.setval('sg_sq_user', 13, true);


--
-- Name: sg_sq_user_rol; Type: SEQUENCE SET; Schema: public; Owner: modulo_base
--

SELECT pg_catalog.setval('sg_sq_user_rol', 28, true);


--
-- Data for Name: sg_tb_rol; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY sg_tb_rol (rol_id, nombre, descripcion, identificador, reg_fec_update, reg_fec_insert) FROM stdin;
\.
COPY sg_tb_rol (rol_id, nombre, descripcion, identificador, reg_fec_update, reg_fec_insert) FROM '$$PATH$$/2039.dat';

--
-- Data for Name: sg_tb_user_rol; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY sg_tb_user_rol (usuario_rol_id, usuario_id, rol_id, valido_desde, valido_hasta, reg_fec_insert, reg_fec_update) FROM stdin;
\.
COPY sg_tb_user_rol (usuario_rol_id, usuario_id, rol_id, valido_desde, valido_hasta, reg_fec_insert, reg_fec_update) FROM '$$PATH$$/2041.dat';

--
-- Data for Name: sg_tb_usuario; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY sg_tb_usuario (usuario_id, identificador, clave, reg_fec_insert, reg_fec_update, email, flag_cambiar_clave, persona_asociada_id) FROM stdin;
\.
COPY sg_tb_usuario (usuario_id, identificador, clave, reg_fec_insert, reg_fec_update, email, flag_cambiar_clave, persona_asociada_id) FROM '$$PATH$$/2040.dat';

--
-- Data for Name: tb_fc_fechas_continuas; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY tb_fc_fechas_continuas (fecha) FROM stdin;
\.
COPY tb_fc_fechas_continuas (fecha) FROM '$$PATH$$/2042.dat';

--
-- Data for Name: tb_ps_parametros_sistema; Type: TABLE DATA; Schema: public; Owner: modulo_base
--

COPY tb_ps_parametros_sistema (nombre, valor, ps_id) FROM stdin;
\.
COPY tb_ps_parametros_sistema (nombre, valor, ps_id) FROM '$$PATH$$/2043.dat';

--
-- Name: bs_tb_sexo_pkey; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY bs_tb_sexo
    ADD CONSTRAINT bs_tb_sexo_pkey PRIMARY KEY (sexo_id);


--
-- Name: consulta_id_pk; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY cs_tb_consulta
    ADD CONSTRAINT consulta_id_pk PRIMARY KEY (consulta_id);


--
-- Name: persona_id_pk; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY bs_tb_persona
    ADD CONSTRAINT persona_id_pk PRIMARY KEY (persona_id);


--
-- Name: persona_unique_identificador; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY bs_tb_persona
    ADD CONSTRAINT persona_unique_identificador UNIQUE (identificador);


--
-- Name: prestador_medico_id_pk; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY cs_tb_prestador_medico
    ADD CONSTRAINT prestador_medico_id_pk PRIMARY KEY (prestador_medico_id);


--
-- Name: sg_tb_rol_pk; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY sg_tb_rol
    ADD CONSTRAINT sg_tb_rol_pk PRIMARY KEY (rol_id);


--
-- Name: sg_tb_user_pk; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY sg_tb_usuario
    ADD CONSTRAINT sg_tb_user_pk PRIMARY KEY (usuario_id);


--
-- Name: sg_tb_user_rol_pk; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY sg_tb_user_rol
    ADD CONSTRAINT sg_tb_user_rol_pk PRIMARY KEY (usuario_rol_id);


--
-- Name: sg_tb_usuario_identificador_key; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY sg_tb_usuario
    ADD CONSTRAINT sg_tb_usuario_identificador_key UNIQUE (identificador);


--
-- Name: sg_tb_usuario_persona_asociada_id_key; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY sg_tb_usuario
    ADD CONSTRAINT sg_tb_usuario_persona_asociada_id_key UNIQUE (persona_asociada_id);


--
-- Name: tb_fc_fechas_continuas_pkey; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY tb_fc_fechas_continuas
    ADD CONSTRAINT tb_fc_fechas_continuas_pkey PRIMARY KEY (fecha);


--
-- Name: tb_ps_parametros_sistema_nombre_key; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY tb_ps_parametros_sistema
    ADD CONSTRAINT tb_ps_parametros_sistema_nombre_key UNIQUE (nombre);


--
-- Name: tb_ps_parametros_sistema_pkey; Type: CONSTRAINT; Schema: public; Owner: modulo_base; Tablespace: 
--

ALTER TABLE ONLY tb_ps_parametros_sistema
    ADD CONSTRAINT tb_ps_parametros_sistema_pkey PRIMARY KEY (ps_id);


--
-- Name: indx_fechas_continuas; Type: INDEX; Schema: public; Owner: modulo_base; Tablespace: 
--

CREATE UNIQUE INDEX indx_fechas_continuas ON tb_fc_fechas_continuas USING btree (fecha DESC);


--
-- Name: persona_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: modulo_base
--

ALTER TABLE ONLY cs_tb_consulta
    ADD CONSTRAINT persona_id_fk FOREIGN KEY (persona_paciente_id) REFERENCES bs_tb_persona(persona_id);


--
-- Name: prestador_persona_fk; Type: FK CONSTRAINT; Schema: public; Owner: modulo_base
--

ALTER TABLE ONLY cs_tb_prestador_medico
    ADD CONSTRAINT prestador_persona_fk FOREIGN KEY (persona_id) REFERENCES bs_tb_persona(persona_id);


--
-- Name: prestador_usuario_fk; Type: FK CONSTRAINT; Schema: public; Owner: modulo_base
--

ALTER TABLE ONLY cs_tb_prestador_medico
    ADD CONSTRAINT prestador_usuario_fk FOREIGN KEY (usuario_id) REFERENCES sg_tb_usuario(usuario_id);


--
-- Name: rol_usuario_rol_fk; Type: FK CONSTRAINT; Schema: public; Owner: modulo_base
--

ALTER TABLE ONLY sg_tb_user_rol
    ADD CONSTRAINT rol_usuario_rol_fk FOREIGN KEY (rol_id) REFERENCES sg_tb_rol(rol_id);


--
-- Name: sg_tb_usuario_persona_asociada_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: modulo_base
--

ALTER TABLE ONLY sg_tb_usuario
    ADD CONSTRAINT sg_tb_usuario_persona_asociada_id_fkey FOREIGN KEY (persona_asociada_id) REFERENCES bs_tb_persona(persona_id);


--
-- Name: usuario_usuario_rol_fk; Type: FK CONSTRAINT; Schema: public; Owner: modulo_base
--

ALTER TABLE ONLY sg_tb_user_rol
    ADD CONSTRAINT usuario_usuario_rol_fk FOREIGN KEY (usuario_id) REFERENCES sg_tb_usuario(usuario_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

